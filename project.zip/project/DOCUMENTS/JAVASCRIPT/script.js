document.addEventListener("DOMContentLoaded", function () {

    const year = document.getElementById("year");

    if (year) {
        year.textContent = new Date().getFullYear();
    }

});

// Contact Form Validation//

function validateForm() {

    const name =
    document.getElementById("name");

    const email =
    document.getElementById("email");

    const message =
    document.getElementById("message");

    if (!name || !email || !message) {
        return true;
    }

    if (name.value.trim() === "") {

        alert("Enter your name");

        name.focus();

        return false;
    }

    if (email.value.trim() === "") {

        alert("Enter your email");

        email.focus();

        return false;
    }

    if (!email.value.includes("@")) {

        alert("Invalid email");

        email.focus();

        return false;
    }

    if (message.value.trim() === "") {

        alert("Enter a message");

        message.focus();

        return false;
    }

    alert("Message submitted successfully!");

    return true;

}

// Gallery Hover Effect //

const images =
document.querySelectorAll(".gallery-grid img");

images.forEach(function(image){

    image.addEventListener("mouseover", function(){

        image.style.transform =
        "scale(1.05)";

        image.style.transition =
        "0.3s";

    });

    image.addEventListener("mouseout", function(){

        image.style.transform =
        "scale(1)";

    });

});
let currentSlide = 0;

const slides =
document.getElementsByClassName("slide");

function displaySlide(){

    for(let i = 0; i < slides.length; i++){

        slides[i].style.display = "none";

    }

    slides[currentSlide].style.display = "block";

}

function changeSlide(n){

    currentSlide += n;

    if(currentSlide >= slides.length){

        currentSlide = 0;

    }

    if(currentSlide < 0){

        currentSlide = slides.length - 1;

    }

    displaySlide();

}

window.onload = function(){

    displaySlide();

    setInterval(function(){

        changeSlide(1);

    },3000);

};

// Back To Top Button //

const topButton =
document.getElementById("topBtn");

window.onscroll = function(){

    if(!topButton) return;

    if(document.body.scrollTop > 200 ||
       document.documentElement.scrollTop > 200){

        topButton.style.display = "block";

    }
    else{

        topButton.style.display = "none";

    }

};

function scrollToTop(){

    window.scrollTo({

        top:0,

        behavior:"smooth"

    });

}

// Counter Animatiom //

function animateCounter(id,target){

    let element =
    document.getElementById(id);

    if(!element) return;

    let count = 0;

    let interval = setInterval(function(){

        count++;

        element.innerHTML = count;

        if(count >= target){

            clearInterval(interval);

        }

    },20);

}

// Equipment Popup // 

function equipmentInfo(name){

    alert(

        "Equipment: " +

        name +

        "\n\nModern and reliable."

    );

}
// navigation //

const links =
document.querySelectorAll("nav a");

links.forEach(function(link){

    link.addEventListener("mouseover",

    function(){

        link.style.color = "orange";

    });

    link.addEventListener("mouseout",

    function(){

        link.style.color = "";

    });

});

// Random Welcome Quotes
const quotes = [

"Welcome to excellence.",

"Connecting people through technology.",

"Your digital partner.",

"Fast. Reliable. Affordable.",

"Technology made easy."

];

function showQuote(){

    let random =

    Math.floor(

        Math.random()

        * quotes.length

    );

    console.log(

        quotes[random]

    );

}

showQuote();

// Smooth Scroll Links //

document.querySelectorAll('a[href^="#"]')

.forEach(anchor => {

    anchor.addEventListener(

        'click',

        function(e){

            e.preventDefault();

            document.querySelector(

                this.getAttribute('href')

            ).scrollIntoView({

                behavior:'smooth'

            });

        }

    );

});

// Fade In Effect // 

window.addEventListener("scroll",

function(){

    const cards =

    document.querySelectorAll(

        ".why-card"

    );

    cards.forEach(function(card){

        const position =

        card.getBoundingClientRect().top;

        const screen =

        window.innerHeight;

        if(position < screen - 100){

            card.style.opacity = "1";

            card.style.transform =

            "translateY(0px)";

        }

    });

});
const sections = document.querySelectorAll(".about-section");

window.addEventListener("scroll", () => {
    sections.forEach(section => {
        if (
            section.getBoundingClientRect().top <
            window.innerHeight - 100
        ) {
            section.classList.add("show");
        }
    });
});